SITE CIPRIANODIGITAL — como publicar
=====================================

Ficheiro principal: index.html (standalone, sem build).
Pasta assets/ tem a foto. NAO apagar.

PUBLICAR COM SURGE (recomendado):
  1. npm install -g surge      (so na 1a vez)
  2. cd para esta pasta
  3. surge
     Email: ciprianodigital2026@gmail.com
     Pass:  Rubencipri1987@
     Dominio: ciprianodigital.pt  (ou .surge.sh)

  Para atualizar: corre 'surge' outra vez na mesma pasta.

PUBLICAR COM NETLIFY (sem terminal):
  - app.netlify.com/drop  -> arrasta esta pasta.

O ficheiro CNAME ja aponta para ciprianodigital.pt (apaga se nao usares).
